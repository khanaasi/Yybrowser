package com.asif.drivebrowser

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.webkit.URLUtil
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class UploadService : Service() {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build()
    private val active = AtomicInteger(0)
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("up", "Drive upload", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val fg = NotificationCompat.Builder(this, "up")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Drive upload chal raha hai")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, fg, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "drivebrowser:upload")
                .apply { acquire(6 * 60 * 60 * 1000L) }
        }

        active.incrementAndGet()
        val nid = 1000 + startId
        Thread {
            try {
                upload(intent, nid)
            } finally {
                if (active.decrementAndGet() == 0) {
                    wl?.let { if (it.isHeld) it.release() }
                    wl = null
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun upload(i: Intent, nid: Int) {
        val url = i.getStringExtra("url") ?: return
        val ua = i.getStringExtra("ua") ?: ""
        val cookie = i.getStringExtra("cookie")
        val ref = i.getStringExtra("referer")
        val cd = i.getStringExtra("cd")
        val mime0 = i.getStringExtra("mime")
        var name = "file"
        try {
            val rb = Request.Builder().url(url).header("User-Agent", ua)
            if (!cookie.isNullOrEmpty()) rb.header("Cookie", cookie)
            if (!ref.isNullOrEmpty()) rb.header("Referer", ref)
            http.newCall(rb.build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("Source ne ${r.code} diya")
                val body = r.body ?: throw IOException("Khaali response")
                val ct = r.header("Content-Type")?.substringBefore(";")?.trim()
                    ?: mime0 ?: "application/octet-stream"
                if (ct.startsWith("text/html")) {
                    throw IOException("File nahi, web page mila (link expire ho gayi?)")
                }
                name = URLUtil.guessFileName(url, r.header("Content-Disposition") ?: cd, ct)
                val total = body.contentLength()
                val session = startSession(name, ct, total)
                push(body, session, total, name, nid)
            }
            note(nid, name, "Drive me upload ho gaya", null, false)
        } catch (e: Exception) {
            note(nid, name, "Fail: ${e.message}", null, false)
        }
    }

    private fun startSession(name: String, mime: String, total: Long): String {
        val acct = GoogleSignIn.getLastSignedInAccount(this)?.account
            ?: throw IOException("Sign in nahi hai")
        val tok = GoogleAuthUtil.getToken(this, acct, "oauth2:https://www.googleapis.com/auth/drive.file")
        val meta = JSONObject().put("name", name).toString()
            .toRequestBody("application/json; charset=UTF-8".toMediaType())
        val rb = Request.Builder()
            .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable")
            .header("Authorization", "Bearer $tok")
            .header("X-Upload-Content-Type", mime)
        if (total > 0) rb.header("X-Upload-Content-Length", total.toString())
        return http.newCall(rb.post(meta).build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Drive session ${r.code}: ${r.body?.string()?.take(200)}")
            r.header("Location") ?: throw IOException("Drive ne session URL nahi diya")
        }
    }

    private fun push(body: ResponseBody, session: String, total: Long, name: String, nid: Int) {
        val size = 5 * 1024 * 1024 // multiple of 256 KB
        val buf = ByteArray(size)
        val inp = body.byteStream()
        var off = 0L
        while (true) {
            var n = 0
            while (n < size) {
                val r = inp.read(buf, n, size - n)
                if (r < 0) break
                n += r
            }
            if (n == 0 && off == 0L) throw IOException("File khaali hai")
            val last = n < size
            val range = when {
                n == 0 -> "bytes */$off"
                last -> "bytes $off-${off + n - 1}/${off + n}"
                total > 0 -> "bytes $off-${off + n - 1}/$total"
                else -> "bytes $off-${off + n - 1}/*"
            }
            val code = putChunk(session, buf, n, range, off + n - 1)
            if (code == 200 || code == 201) return
            if (last || n == 0) throw IOException("Drive ne $code diya")
            off += n
            val pct = if (total > 0) (off * 100 / total).toInt() else null
            note(nid, name, "${off / 1048576} MB uploaded", pct, true)
        }
    }

    private fun putChunk(session: String, buf: ByteArray, n: Int, range: String, end: Long): Int {
        var err: Exception? = null
        for (a in 1..4) {
            try {
                val req = Request.Builder().url(session)
                    .header("Content-Range", range)
                    .put(buf.toRequestBody(null, 0, n))
                    .build()
                http.newCall(req).execute().use { r ->
                    if (r.code == 200 || r.code == 201) return r.code
                    if (r.code == 308) {
                        val got = r.header("Range")?.substringAfter("-")?.toLongOrNull()
                        if (n > 0 && got != null && got != end) throw IOException("Chunk poora save nahi hua")
                        return 308
                    }
                    if (r.code < 500) throw IOException("Drive ${r.code}: ${r.body?.string()?.take(200)}")
                    err = IOException("Drive ${r.code}")
                }
            } catch (e: IOException) {
                err = e
            }
            Thread.sleep(2000L * a)
        }
        throw err ?: IOException("Upload fail")
    }

    private fun note(nid: Int, name: String, text: String, pct: Int?, ongoing: Boolean) {
        val b = NotificationCompat.Builder(this, "up")
            .setSmallIcon(
                if (ongoing) android.R.drawable.stat_sys_upload else android.R.drawable.stat_sys_upload_done
            )
            .setContentTitle(name)
            .setContentText(text)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
        if (ongoing) {
            if (pct == null) b.setProgress(0, 0, true) else b.setProgress(100, pct, false)
        }
        getSystemService(NotificationManager::class.java).notify(nid, b.build())
    }
}
