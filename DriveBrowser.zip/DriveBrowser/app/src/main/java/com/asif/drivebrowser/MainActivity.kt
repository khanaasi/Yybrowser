package com.asif.drivebrowser

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import java.net.URLEncoder

class MainActivity : Activity() {

    private val tabs = mutableListOf<WebView>()
    private var cur = -1
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var holder: FrameLayout
    private val rcSign = 1001
    private val home = "https://www.google.com"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun curWeb(): WebView? = tabs.getOrNull(cur)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        urlBar = EditText(this).apply {
            hint = "Search ya URL"
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setOnEditorActionListener { _, _, _ -> go(text.toString()); true }
        }
        val goBtn = Button(this).apply {
            text = "Go"
            setOnClickListener { go(urlBar.text.toString()) }
        }
        top.addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(goBtn)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        holder = FrameLayout(this)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                setOnClickListener { action() }
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        btn("<") { curWeb()?.let { if (it.canGoBack()) it.goBack() } }
        btn(">") { curWeb()?.let { if (it.canGoForward()) it.goForward() } }
        btn("Reload") { curWeb()?.reload() }
        btn("Tabs") { tabsMenu() }
        btn("Drive") { driveMenu() }

        root.addView(top)
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottom)
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        newTab(intent?.dataString ?: home)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.dataString?.let { newTab(it) }
    }

    // ---------- tabs ----------

    private fun newTab(url: String?, w: WebView? = null): WebView {
        val web = w ?: makeWeb()
        tabs.add(web)
        select(tabs.size - 1)
        if (url != null) web.loadUrl(url)
        return web
    }

    private fun select(i: Int) {
        cur = i
        holder.removeAllViews()
        holder.addView(
            tabs[i],
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        urlBar.setText(tabs[i].url ?: "")
        progress.visibility = View.GONE
    }

    private fun closeTab(i: Int) {
        val w = tabs.removeAt(i)
        holder.removeView(w)
        w.destroy()
        if (tabs.isEmpty()) {
            newTab(home)
        } else {
            select(minOf(i, tabs.size - 1))
        }
    }

    private fun tabsMenu() {
        val items = arrayOf("+ New tab") + tabs.map { it.title ?: it.url ?: "Tab" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(items) { _, i -> if (i == 0) newTab(home) else select(i - 1) }
            .setNeutralButton("Close this tab") { _, _ -> closeTab(cur) }
            .show()
    }

    // ---------- webview ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(): WebView {
        val web = WebView(this)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString.replace("; wv", "")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                val ok = u.startsWith("http://") || u.startsWith("https://") ||
                    u.startsWith("about:") || u.startsWith("blob:") || u.startsWith("data:")
                return !ok
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                if (view === curWeb()) urlBar.setText(url ?: "")
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (view === curWeb()) {
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    progress.progress = newProgress
                }
            }

            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                if (!isUserGesture) return false
                val nw = makeWeb()
                newTab(null, nw)
                (resultMsg.obj as WebView.WebViewTransport).webView = nw
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                val i = tabs.indexOf(window)
                if (i >= 0) closeTab(i)
            }
        }

        web.setDownloadListener { url, ua, cd, mime, _ -> onDownload(web, url, ua, cd, mime) }
        return web
    }

    private fun onDownload(web: WebView, url: String, ua: String, cd: String?, mime: String?) {
        if (!url.startsWith("http")) {
            toast("Ye link type (blob/data) abhi support nahi hai")
            return
        }
        if (GoogleSignIn.getLastSignedInAccount(this) == null) {
            toast("Pehle neeche Drive button se sign in karo")
            return
        }
        val i = Intent(this, UploadService::class.java)
            .putExtra("url", url)
            .putExtra("ua", ua)
            .putExtra("cd", cd)
            .putExtra("mime", mime)
            .putExtra("cookie", CookieManager.getInstance().getCookie(url))
            .putExtra("referer", web.url)
        ContextCompat.startForegroundService(this, i)
        toast("Drive upload shuru")
    }

    private fun go(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        val u = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") ->
                "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
            else -> "https://$t"
        }
        curWeb()?.loadUrl(u)
        urlBar.clearFocus()
    }

    // ---------- google sign in ----------

    private fun gsc(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope("https://www.googleapis.com/auth/drive.file"))
            .build()
        return GoogleSignIn.getClient(this, gso)
    }

    private fun driveMenu() {
        val a = GoogleSignIn.getLastSignedInAccount(this)
        if (a == null) {
            startActivityForResult(gsc().signInIntent, rcSign)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Drive: ${a.email}")
            .setPositiveButton("OK", null)
            .setNegativeButton("Sign out") { _, _ -> gsc().signOut() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == rcSign) {
            GoogleSignIn.getSignedInAccountFromIntent(data)
                .addOnSuccessListener { toast("Signed in: ${it.email}") }
                .addOnFailureListener { toast("Sign in fail: ${it.message}") }
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val w = curWeb()
        if (w != null && w.canGoBack()) w.goBack()
        else if (tabs.size > 1) closeTab(cur)
        else super.onBackPressed()
    }
}
